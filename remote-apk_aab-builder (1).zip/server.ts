import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import multer from 'multer';
import AdmZip from 'adm-zip';
import { spawn } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const upload = multer({ dest: '/tmp/uploads/' });

async function startServer() {
  const app = express();
  const PORT = 3000;

  // API Routes
  app.post('/build', upload.single('file'), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ detail: 'No file uploaded' });
    }

    const projectDir = path.join('/tmp', 'project-' + Date.now());
    const keystorePath = path.join('/tmp', 'release-' + Date.now() + '.jks');
    
    try {
      // 1. Check for required environment variables
      const requiredEnv = ['ENCODED_KEYSTORE', 'KS_PASS', 'KS_ALIAS', 'KEY_PASS'];
      const missingEnv = requiredEnv.filter(key => !process.env[key]);
      
      if (missingEnv.length > 0) {
        throw new Error(`Missing required environment variables: ${missingEnv.join(', ')}. Please configure these in the AI Studio Secrets panel.`);
      }

      const encodedKeystore = process.env.ENCODED_KEYSTORE!;
      fs.writeFileSync(keystorePath, Buffer.from(encodedKeystore, 'base64'));

      // 2. Extract Project
      const zip = new AdmZip(req.file.path);
      zip.extractAllTo(projectDir, true);

      // 3. Find gradlew and make executable
      let gradlewPath = path.join(projectDir, 'gradlew');
      if (!fs.existsSync(gradlewPath)) {
        // Check for subfolder
        const files = fs.readdirSync(projectDir);
        if (files.length === 1 && fs.statSync(path.join(projectDir, files[0])).isDirectory()) {
          const subDir = path.join(projectDir, files[0]);
          if (fs.existsSync(path.join(subDir, 'gradlew'))) {
            // Move contents up
            const subFiles = fs.readdirSync(subDir);
            for (const f of subFiles) {
              fs.renameSync(path.join(subDir, f), path.join(projectDir, f));
            }
            fs.rmdirSync(subDir);
          }
        }
      }

      if (!fs.existsSync(gradlewPath)) {
        throw new Error('gradlew not found in project root');
      }

      fs.chmodSync(gradlewPath, 0o755);

      // 4. Build Execution
      const ksPass = process.env.KS_PASS;
      const ksAlias = process.env.KS_ALIAS;
      const keyPass = process.env.KEY_PASS;

      const args = [
        'bundleRelease',
        '--no-daemon',
        '--max-workers=2',
        `-Pandroid.injected.signing.store.file=${keystorePath}`,
        `-Pandroid.injected.signing.store.password=${ksPass}`,
        `-Pandroid.injected.signing.key.alias=${ksAlias}`,
        `-Pandroid.injected.signing.key.password=${keyPass}`,
      ];

      console.log(`Starting build in ${projectDir} with args: ${args.join(' ')}`);

      const child = spawn('./gradlew', args, {
        cwd: projectDir,
        env: { 
          ...process.env, 
          // Use system JAVA_HOME if set, otherwise fallback to common path
          JAVA_HOME: process.env.JAVA_HOME || '/usr/lib/jvm/java-17-openjdk-amd64' 
        }
      });

      let stdout = '';
      let stderr = '';

      child.stdout.on('data', (data) => { stdout += data; });
      child.stderr.on('data', (data) => { stderr += data; });

      child.on('close', (code) => {
        try {
          if (code !== 0) {
            console.error(`Build failed with code ${code}`);
            console.error(stderr || stdout);
            return res.status(500).json({ detail: `Build failed: ${stderr || stdout}` });
          }

          // 5. Locate AAB
          const bundleDir = path.join(projectDir, 'app', 'build', 'outputs', 'bundle', 'release');
          if (!fs.existsSync(bundleDir)) {
            return res.status(500).json({ detail: 'Build succeeded but output directory not found.' });
          }

          const files = fs.readdirSync(bundleDir);
          const aabFile = files.find(f => f.endsWith('.aab'));

          if (!aabFile) {
            return res.status(500).json({ detail: 'Build succeeded but AAB file not found.' });
          }

          const targetPath = path.join(bundleDir, aabFile);
          res.download(targetPath, aabFile, (err) => {
            // Cleanup after download
            try {
              if (fs.existsSync(projectDir)) fs.rmSync(projectDir, { recursive: true, force: true });
              if (fs.existsSync(keystorePath)) fs.unlinkSync(keystorePath);
              if (fs.existsSync(req.file!.path)) fs.unlinkSync(req.file!.path);
            } catch (cleanupErr) {
              console.error('Cleanup error:', cleanupErr);
            }
          });
        } catch (err: any) {
          res.status(500).json({ detail: err.message });
        }
      });

    } catch (err: any) {
      console.error('Build initialization error:', err);
      // Cleanup
      if (fs.existsSync(projectDir)) fs.rmSync(projectDir, { recursive: true, force: true });
      if (fs.existsSync(keystorePath)) fs.unlinkSync(keystorePath);
      if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      
      res.status(500).json({ detail: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
