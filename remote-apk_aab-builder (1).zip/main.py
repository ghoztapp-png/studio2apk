import os
import shutil
import base64
import subprocess
import zipfile
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pathlib import Path

app = FastAPI(title="Remote APK/AAB Builder")

# Configuration from environment variables
KS_PASS = os.getenv("KS_PASS")
KS_ALIAS = os.getenv("KS_ALIAS")
KEY_PASS = os.getenv("KEY_PASS")
ENCODED_KEYSTORE = os.getenv("ENCODED_KEYSTORE")

TMP_DIR = Path("/tmp")
PROJECT_DIR = TMP_DIR / "project"
KEYSTORE_PATH = TMP_DIR / "release.jks"

def cleanup():
    """Removes temporary project files and keystore."""
    if PROJECT_DIR.exists():
        shutil.rmtree(PROJECT_DIR)
    if KEYSTORE_PATH.exists():
        KEYSTORE_PATH.unlink()

@app.post("/build")
async def build_aab(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    if not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Only ZIP files are accepted.")

    # 1. Cleanup previous builds if any
    cleanup()

    try:
        # 2. Save and Decode Keystore
        if not ENCODED_KEYSTORE:
            raise HTTPException(status_code=500, detail="ENCODED_KEYSTORE environment variable is missing.")
        
        with open(KEYSTORE_PATH, "wb") as f:
            f.write(base64.b64decode(ENCODED_KEYSTORE))

        # 3. Extract Project
        PROJECT_DIR.mkdir(parents=True, exist_ok=True)
        zip_path = TMP_DIR / "upload.zip"
        with open(zip_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(PROJECT_DIR)
        
        zip_path.unlink()

        # 4. Make gradlew executable
        gradlew_path = PROJECT_DIR / "gradlew"
        if not gradlew_path.exists():
            # Try to find it in a subdirectory if the zip had a root folder
            subdirs = [d for d in PROJECT_DIR.iterdir() if d.is_dir()]
            if len(subdirs) == 1 and (subdirs[0] / "gradlew").exists():
                # Move contents up
                for item in subdirs[0].iterdir():
                    shutil.move(str(item), str(PROJECT_DIR))
                subdirs[0].rmdir()
            
            if not gradlew_path.exists():
                raise HTTPException(status_code=400, detail="gradlew not found in the project root.")

        os.chmod(str(gradlew_path), 0o755)

        # 5. Build Execution
        # Inject signing properties via -P flags
        build_cmd = [
            "./gradlew",
            "bundleRelease",
            "--no-daemon",
            "--max-workers=2",
            f"-Pandroid.injected.signing.store.file={KEYSTORE_PATH}",
            f"-Pandroid.injected.signing.store.password={KS_PASS}",
            f"-Pandroid.injected.signing.key.alias={KS_ALIAS}",
            f"-Pandroid.injected.signing.key.password={KEY_PASS}",
        ]

        process = subprocess.run(
            build_cmd,
            cwd=str(PROJECT_DIR),
            capture_output=True,
            text=True
        )

        if process.returncode != 0:
            error_msg = process.stderr or process.stdout
            print(f"Build failed: {error_msg}")
            raise HTTPException(status_code=500, detail=f"Build failed: {error_msg}")

        # 6. Locate AAB
        # Standard path: app/build/outputs/bundle/release/app-release.aab
        # We search for any .aab in the outputs folder to be safe
        bundle_dir = PROJECT_DIR / "app" / "build" / "outputs" / "bundle" / "release"
        aab_files = list(bundle_dir.glob("*.aab"))
        
        if not aab_files:
            raise HTTPException(status_code=500, detail="Build succeeded but AAB file was not found.")

        target_aab = aab_files[0]
        
        # Copy to a safe place before cleanup
        output_path = TMP_DIR / target_aab.name
        shutil.copy(target_aab, output_path)

        # Schedule cleanup
        background_tasks.add_task(cleanup)
        background_tasks.add_task(lambda: output_path.unlink() if output_path.exists() else None)

        return FileResponse(
            path=output_path,
            filename=target_aab.name,
            media_type="application/octet-stream"
        )

    except Exception as e:
        cleanup()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
