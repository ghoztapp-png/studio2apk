import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileArchive, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Download, 
  Terminal,
  Settings,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import axios from 'axios';

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'uploading' | 'building' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStatus('idle');
      setError(null);
      setDownloadUrl(null);
    }
  };

  const startBuild = async () => {
    if (!file) return;

    setStatus('uploading');
    setError(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Note: In this preview environment, the FastAPI server might not be running.
      // This UI is primarily a demo of the tool requested.
      setStatus('building');
      
      const response = await axios.post('/build', formData, {
        responseType: 'blob',
        timeout: 600000, // 10 minutes for build
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      setDownloadUrl(url);
      setStatus('success');
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setError(err.response?.data?.detail || err.message || 'An unknown error occurred during build.');
    }
  };

  return (
    <div className="min-h-screen bg-bg text-ink font-sans selection:bg-accent selection:text-white">
      {/* Header */}
      <header className="border-b border-line p-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-bg flex items-center justify-center rounded-sm">
            <Cpu size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight uppercase">Remote APK/AAB Builder</h1>
            <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">v1.0.0 // Build Pipeline</p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2 px-3 py-1 border border-line rounded-full text-[11px] font-mono opacity-70">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            SYSTEM_READY
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Upload & Controls */}
        <div className="lg:col-span-2 space-y-8">
          <section className="border border-line rounded-sm overflow-hidden bg-white/50">
            <div className="bg-ink text-bg px-4 py-2 flex justify-between items-center">
              <span className="text-[11px] font-mono uppercase tracking-widest flex items-center gap-2">
                <Terminal size={12} /> Input_Source
              </span>
              <span className="text-[10px] opacity-50">*.ZIP</span>
            </div>
            
            <div className="p-12 flex flex-col items-center justify-center border-b border-line border-dashed">
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".zip"
                className="hidden"
              />
              
              <AnimatePresence mode="wait">
                {!file ? (
                  <motion.div 
                    key="empty"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex flex-col items-center text-center"
                  >
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-20 h-20 border-2 border-line border-dashed rounded-full flex items-center justify-center cursor-pointer hover:bg-ink hover:text-bg transition-colors mb-4"
                    >
                      <Upload size={32} />
                    </div>
                    <h3 className="text-lg font-medium mb-1">Upload Android Project</h3>
                    <p className="text-sm opacity-60 max-w-xs">
                      Select a ZIP file containing your Android project root (with gradlew).
                    </p>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="selected"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center"
                  >
                    <div className="w-20 h-20 bg-ink text-bg rounded-full flex items-center justify-center mb-4">
                      <FileArchive size={32} />
                    </div>
                    <h3 className="text-lg font-medium mb-1">{file.name}</h3>
                    <p className="text-sm opacity-60 mb-6">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    <button 
                      onClick={() => setFile(null)}
                      className="text-[10px] font-mono uppercase tracking-widest opacity-50 hover:opacity-100 underline"
                    >
                      Change File
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="p-6 flex justify-center">
              <button
                disabled={!file || status === 'uploading' || status === 'building'}
                onClick={startBuild}
                className={`
                  px-8 py-3 rounded-sm font-bold uppercase tracking-widest text-sm flex items-center gap-3 transition-all
                  ${!file || status === 'uploading' || status === 'building'
                    ? 'bg-line/10 text-ink/30 cursor-not-allowed'
                    : 'bg-ink text-bg hover:bg-accent hover:scale-[1.02] active:scale-[0.98]'}
                `}
              >
                {status === 'uploading' || status === 'building' ? (
                  <>
                    <Loader2 className="animate-spin" size={18} />
                    {status === 'uploading' ? 'Uploading...' : 'Building AAB...'}
                  </>
                ) : (
                  <>
                    <Cpu size={18} />
                    Start Build Pipeline
                  </>
                )}
              </button>
            </div>
          </section>

          {/* Status Display */}
          <AnimatePresence shadow-sm>
            {status !== 'idle' && (
              <motion.section 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`border border-line rounded-sm p-6 flex items-start gap-4 ${
                  status === 'success' ? 'bg-green-50 border-green-200' : 
                  status === 'error' ? 'bg-red-50 border-red-200' : 'bg-white'
                }`}
              >
                <div className="mt-1">
                  {status === 'success' && <CheckCircle2 className="text-green-600" />}
                  {status === 'error' && <AlertCircle className="text-red-600" />}
                  {(status === 'uploading' || status === 'building') && <Loader2 className="animate-spin text-ink" />}
                </div>
                <div className="flex-1">
                  <h4 className="font-bold uppercase text-xs tracking-wider mb-1">
                    {status === 'uploading' && 'Step 1: Uploading Artifacts'}
                    {status === 'building' && 'Step 2: Compiling & Signing'}
                    {status === 'success' && 'Build Complete'}
                    {status === 'error' && 'Pipeline Failed'}
                  </h4>
                  <p className="text-sm opacity-70">
                    {status === 'uploading' && 'Transferring project ZIP to remote build server...'}
                    {status === 'building' && 'Executing ./gradlew bundleRelease with injected signing keys. This may take several minutes.'}
                    {status === 'success' && 'Your signed AAB is ready for download.'}
                    {status === 'error' && error}
                  </p>

                  {status === 'error' && error?.includes('environment variable') && (
                    <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-sm text-[11px] text-amber-800">
                      <strong>Tip:</strong> Open the <strong>Settings</strong> menu (gear icon) in AI Studio and add the required secrets to the <strong>Secrets</strong> panel.
                    </div>
                  )}
                  
                  {status === 'success' && downloadUrl && (
                    <a 
                      href={downloadUrl} 
                      download="app-release.aab"
                      className="mt-4 inline-flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-sm text-xs font-bold uppercase tracking-widest hover:bg-green-700 transition-colors"
                    >
                      <Download size={14} /> Download AAB
                    </a>
                  )}
                </div>
              </motion.section>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Info & Config */}
        <div className="space-y-8">
          <section className="border border-line rounded-sm bg-white p-6">
            <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 mb-4 flex items-center gap-2">
              <Settings size={14} /> Configuration
            </h3>
            <div className="space-y-4">
              <div className="p-3 bg-bg/50 rounded-sm border border-line/20">
                <p className="text-[10px] font-mono opacity-50 uppercase mb-1">Target_Format</p>
                <p className="text-sm font-bold">Android App Bundle (.aab)</p>
              </div>
              <div className="p-3 bg-bg/50 rounded-sm border border-line/20">
                <p className="text-[10px] font-mono opacity-50 uppercase mb-1">Build_Tools</p>
                <p className="text-sm font-bold">v34.0.0</p>
              </div>
              <div className="p-3 bg-bg/50 rounded-sm border border-line/20">
                <p className="text-[10px] font-mono opacity-50 uppercase mb-1">JDK_Version</p>
                <p className="text-sm font-bold">OpenJDK 17</p>
              </div>
            </div>
          </section>

          <section className="border border-line rounded-sm bg-white p-6">
            <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 mb-4 flex items-center gap-2">
              <ShieldCheck size={14} /> Signing_Status
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-60">Keystore</span>
                <span className="font-mono text-[10px] bg-green-100 text-green-800 px-2 py-0.5 rounded">LOADED</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-60">Alias</span>
                <span className="font-mono text-[10px] bg-green-100 text-green-800 px-2 py-0.5 rounded">VERIFIED</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-60">Passwords</span>
                <span className="font-mono text-[10px] bg-green-100 text-green-800 px-2 py-0.5 rounded">SET</span>
              </div>
              <p className="text-[10px] opacity-40 mt-4 italic">
                Keys are injected at runtime via environment variables.
              </p>
            </div>
          </section>

          <section className="p-6 bg-ink text-bg rounded-sm">
            <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 mb-3">Deployment_Note</h3>
            <p className="text-xs leading-relaxed opacity-80">
              This application is designed to be deployed as a Docker container on platforms like Railway.app. 
              The backend (FastAPI) handles the heavy lifting of Android compilation.
            </p>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-line p-8 text-center">
        <p className="text-[10px] font-mono opacity-40 uppercase tracking-[0.2em]">
          Remote Build Engine // Secure Artifact Generation // © 2026
        </p>
      </footer>
    </div>
  );
}
